import {
  BgMode,
  BikeType,
  ColorTheme,
  GearItem,
  RecoveryMode,
  RouteData,
  SkyTrailBackupFile,
  TrackPoint,
  TripSettings,
  UserProfile,
  WeatherProvider,
} from '../types';

const USERS_LIST_KEY = 'skytrail_users_v1';
const ACTIVE_USER_ID_KEY = 'skytrail_active_user_id_v1';
const GUEST_ROUTES_KEY = 'skytrail_saved_routes';
const GUEST_SETTINGS_KEY = 'skytrail_appearance_v1';
const GUEST_GEAR_KEY = 'skytrail_gear_v1';
const AUTO_RECOVERY_KEY = 'skytrail_auto_recovery_snapshot_v1';

const VALID_COLOR_THEMES: ColorTheme[] = [
  'sky',
  'emerald',
  'amber',
  'violet',
  'rose',
  'teal',
  'indigo',
  'orange',
];
const VALID_BG_MODES: BgMode[] = ['light', 'tinted', 'dark', 'midnight'];
const VALID_PROVIDERS: WeatherProvider[] = [
  'open_meteo_auto',
  'ecmwf',
  'dwd_icon',
  'met_no',
  'noaa_gfs',
];
const VALID_BIKE_TYPES: BikeType[] = ['road', 'gravel', 'mtb', 'touring', 'ebike'];

const AVATAR_COLORS = [
  '#0284c7',
  '#059669',
  '#7c3aed',
  '#d97706',
  '#e11d48',
  '#0d9488',
  '#4f46e5',
  '#ea580c',
];

export function getDefaultSettings(): TripSettings {
  return {
    departureDate: new Date().toISOString().split('T')[0],
    departureTime: '09:00',
    bikeType: 'gravel',
    speedKmH: 22,
    breakMinutes: 0,
    realisticPace: true,
    colorTheme: 'sky',
    bgMode: 'light',
    weatherProvider: 'open_meteo_auto',
  };
}

function getRoutesKey(userId: string | null): string {
  return userId ? `skytrail_u_${userId}_routes` : GUEST_ROUTES_KEY;
}

function getSettingsKey(userId: string | null): string {
  return userId ? `skytrail_u_${userId}_settings` : GUEST_SETTINGS_KEY;
}

function getGearKey(userId: string | null): string {
  return userId ? `skytrail_u_${userId}_gear` : GUEST_GEAR_KEY;
}

export async function hashSecret(secret: string): Promise<string> {
  const normalized = secret.trim();
  if (!normalized) return '';
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(`skytrail-salt:${normalized}`);
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  // Fallback deterministic encoding only when crypto.subtle is unavailable
  return btoa(unescape(encodeURIComponent(`skytrail:${normalized}`)));
}

export function loadProfiles(): UserProfile[] {
  try {
    const raw = localStorage.getItem(USERS_LIST_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveProfiles(profiles: UserProfile[]) {
  try {
    localStorage.setItem(USERS_LIST_KEY, JSON.stringify(profiles));
  } catch {
    // Ignore storage errors
  }
}

export function getActiveUser(): UserProfile | null {
  try {
    const activeId = localStorage.getItem(ACTIVE_USER_ID_KEY);
    if (!activeId) return null;
    const profiles = loadProfiles();
    return profiles.find((u) => u.id === activeId) ?? null;
  } catch {
    return null;
  }
}

export function setActiveUserId(userId: string | null) {
  try {
    if (userId) {
      localStorage.setItem(ACTIVE_USER_ID_KEY, userId);
    } else {
      localStorage.removeItem(ACTIVE_USER_ID_KEY);
    }
  } catch {
    // Ignore storage errors
  }
}

export async function createUserProfile(params: {
  name: string;
  email: string;
  pin?: string;
  migrateGuestData?: boolean;
}): Promise<UserProfile> {
  const profiles = loadProfiles();
  const normalizedEmail = params.email.trim().toLowerCase();
  if (!params.name.trim()) {
    throw new Error('Podaj nazwę użytkownika.');
  }
  if (!normalizedEmail || !normalizedEmail.includes('@')) {
    throw new Error('Podaj poprawny adres e-mail.');
  }
  if (profiles.some((p) => p.email.toLowerCase() === normalizedEmail)) {
    throw new Error('Konto z tym adresem e-mail już istnieje. Wybierz logowanie.');
  }

  const now = new Date().toISOString();
  const pinHash = params.pin && params.pin.trim() ? await hashSecret(params.pin) : undefined;
  const id = `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const avatarColor = AVATAR_COLORS[profiles.length % AVATAR_COLORS.length];

  const newProfile: UserProfile = {
    id,
    name: params.name.trim(),
    email: normalizedEmail,
    pinHash,
    avatarColor,
    createdAt: now,
    lastLoginAt: now,
  };

  if (params.migrateGuestData) {
    const guestRoutes = loadSavedRoutes(null);
    const guestSettings = loadUserSettings(null);
    const guestGear = loadGearState(null);
    saveSavedRoutes(id, guestRoutes);
    saveUserSettings(id, guestSettings);
    if (guestGear.length > 0) {
      saveGearState(id, guestGear);
    }
  } else {
    saveUserSettings(id, getDefaultSettings());
    saveSavedRoutes(id, []);
  }

  saveProfiles([newProfile, ...profiles]);
  setActiveUserId(id);
  return newProfile;
}

export async function authenticateProfile(params: {
  emailOrId: string;
  pin?: string;
}): Promise<UserProfile> {
  const profiles = loadProfiles();
  const needle = params.emailOrId.trim().toLowerCase();
  const profile = profiles.find(
    (p) => p.id.toLowerCase() === needle || p.email.toLowerCase() === needle
  );

  if (!profile) {
    throw new Error('Nie znaleziono profilu o podanym adresie e-mail.');
  }

  if (profile.pinHash) {
    const inputHash = await hashSecret(params.pin || '');
    if (inputHash !== profile.pinHash) {
      throw new Error('Nieprawidłowe hasło lub PIN dla tego konta.');
    }
  }

  const updatedProfile: UserProfile = {
    ...profile,
    lastLoginAt: new Date().toISOString(),
  };
  saveProfiles(profiles.map((p) => (p.id === profile.id ? updatedProfile : p)));
  setActiveUserId(profile.id);
  return updatedProfile;
}

export function deleteUserProfile(userId: string) {
  const profiles = loadProfiles().filter((p) => p.id !== userId);
  saveProfiles(profiles);
  try {
    localStorage.removeItem(getRoutesKey(userId));
    localStorage.removeItem(getSettingsKey(userId));
    localStorage.removeItem(getGearKey(userId));
    if (localStorage.getItem(ACTIVE_USER_ID_KEY) === userId) {
      localStorage.removeItem(ACTIVE_USER_ID_KEY);
    }
  } catch {
    // Ignore errors
  }
}

export function sanitizeSettings(raw: Partial<TripSettings> | null | undefined): TripSettings {
  const defaults = getDefaultSettings();
  if (!raw || typeof raw !== 'object') return defaults;

  const speed =
    typeof raw.speedKmH === 'number' && Number.isFinite(raw.speedKmH)
      ? Math.min(45, Math.max(8, Math.round(raw.speedKmH)))
      : defaults.speedKmH;

  const breakMin =
    typeof raw.breakMinutes === 'number' && Number.isFinite(raw.breakMinutes)
      ? Math.min(240, Math.max(0, Math.round(raw.breakMinutes)))
      : defaults.breakMinutes;

  const departureDate =
    typeof raw.departureDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.departureDate)
      ? raw.departureDate
      : defaults.departureDate;

  const departureTime =
    typeof raw.departureTime === 'string' && /^\d{2}:\d{2}$/.test(raw.departureTime)
      ? raw.departureTime
      : defaults.departureTime;

  return {
    departureDate,
    departureTime,
    bikeType: VALID_BIKE_TYPES.includes(raw.bikeType as BikeType)
      ? (raw.bikeType as BikeType)
      : defaults.bikeType,
    speedKmH: speed,
    breakMinutes: breakMin,
    realisticPace: typeof raw.realisticPace === 'boolean' ? raw.realisticPace : defaults.realisticPace,
    colorTheme: VALID_COLOR_THEMES.includes(raw.colorTheme as ColorTheme)
      ? (raw.colorTheme as ColorTheme)
      : defaults.colorTheme,
    bgMode: VALID_BG_MODES.includes(raw.bgMode as BgMode)
      ? (raw.bgMode as BgMode)
      : defaults.bgMode,
    weatherProvider: VALID_PROVIDERS.includes(raw.weatherProvider as WeatherProvider)
      ? (raw.weatherProvider as WeatherProvider)
      : defaults.weatherProvider,
  };
}

export function loadUserSettings(userId: string | null): TripSettings {
  try {
    const raw = localStorage.getItem(getSettingsKey(userId));
    if (!raw) return getDefaultSettings();
    return sanitizeSettings(JSON.parse(raw));
  } catch {
    return getDefaultSettings();
  }
}

export function saveUserSettings(userId: string | null, settings: TripSettings) {
  try {
    localStorage.setItem(getSettingsKey(userId), JSON.stringify(settings));
  } catch {
    // Ignore storage write errors
  }
}

export function loadSavedRoutes(userId: string | null): RouteData[] {
  try {
    const raw = localStorage.getItem(getRoutesKey(userId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveSavedRoutes(userId: string | null, routes: RouteData[]) {
  try {
    localStorage.setItem(getRoutesKey(userId), JSON.stringify(routes));
  } catch {
    // Ignore storage write errors
  }
}

export function loadGearState(userId: string | null): GearItem[] {
  try {
    const raw = localStorage.getItem(getGearKey(userId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveGearState(userId: string | null, items: GearItem[]) {
  try {
    localStorage.setItem(getGearKey(userId), JSON.stringify(items));
  } catch {
    // Ignore storage write errors
  }
}

function isValidTrackPoint(p: unknown): p is TrackPoint {
  if (!p || typeof p !== 'object') return false;
  const pt = p as Record<string, unknown>;
  return (
    typeof pt.lat === 'number' &&
    Number.isFinite(pt.lat) &&
    typeof pt.lon === 'number' &&
    Number.isFinite(pt.lon) &&
    typeof pt.elevation === 'number' &&
    Number.isFinite(pt.elevation) &&
    typeof pt.distanceFromStart === 'number' &&
    Number.isFinite(pt.distanceFromStart)
  );
}

function sanitizeRoute(raw: unknown, idx: number): RouteData | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.name !== 'string' || !Array.isArray(r.points)) return null;
  const validPoints = r.points.filter(isValidTrackPoint);
  if (validPoints.length < 2) return null;

  return {
    id: typeof r.id === 'string' && r.id ? r.id : `restored_${Date.now()}_${idx}`,
    name: r.name.trim() || `Trasa #${idx + 1}`,
    points: validPoints,
    totalDistance:
      typeof r.totalDistance === 'number' && Number.isFinite(r.totalDistance)
        ? r.totalDistance
        : Number(validPoints[validPoints.length - 1].distanceFromStart.toFixed(1)),
    elevationGain:
      typeof r.elevationGain === 'number' && Number.isFinite(r.elevationGain)
        ? r.elevationGain
        : 0,
    elevationLoss:
      typeof r.elevationLoss === 'number' && Number.isFinite(r.elevationLoss)
        ? r.elevationLoss
        : 0,
    minElevation:
      typeof r.minElevation === 'number' && Number.isFinite(r.minElevation)
        ? r.minElevation
        : Math.round(Math.min(...validPoints.map((pt) => pt.elevation))),
    maxElevation:
      typeof r.maxElevation === 'number' && Number.isFinite(r.maxElevation)
        ? r.maxElevation
        : Math.round(Math.max(...validPoints.map((pt) => pt.elevation))),
    createdAt:
      typeof r.createdAt === 'string'
        ? r.createdAt
        : new Date().toLocaleDateString('pl-PL'),
  };
}

export function buildBackupPayload(params: {
  user: UserProfile | null;
  settings: TripSettings;
  savedRoutes: RouteData[];
  activeRoute: RouteData | null;
  gearItems?: GearItem[];
}): SkyTrailBackupFile {
  return {
    schemaVersion: 1,
    app: 'SkyTrail',
    exportedAt: new Date().toISOString(),
    profile: params.user
      ? {
          name: params.user.name,
          email: params.user.email,
          avatarColor: params.user.avatarColor,
        }
      : null,
    settings: params.settings,
    savedRoutes: params.savedRoutes,
    activeRoute: params.activeRoute,
    gearItems: params.gearItems ?? loadGearState(params.user?.id ?? null),
  };
}

export function downloadBackupFile(payload: SkyTrailBackupFile) {
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const datePart = new Date().toISOString().slice(0, 10);
  const profileSlug = payload.profile?.name
    ? `_${payload.profile.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}`
    : '';
  const link = document.createElement('a');
  link.href = url;
  link.download = `skytrail_kopia${profileSlug}_${datePart}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function parseAndValidateBackup(jsonText: string): SkyTrailBackupFile {
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    throw new Error('Wybrany plik nie jest poprawnym plikiem JSON.');
  }

  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Nieprawidłowa struktura pliku kopii zapasowej.');
  }

  const obj = parsed as Record<string, unknown>;
  if (obj.app !== 'SkyTrail') {
    throw new Error('Ten plik nie jest kopią zapasową aplikacji SkyTrail.');
  }

  const sanitizedSettings = sanitizeSettings(obj.settings as Partial<TripSettings>);
  const rawRoutes = Array.isArray(obj.savedRoutes) ? obj.savedRoutes : [];
  const sanitizedRoutes = rawRoutes
    .map((r, i) => sanitizeRoute(r, i))
    .filter((r): r is RouteData => r !== null);

  const sanitizedActiveRoute = obj.activeRoute ? sanitizeRoute(obj.activeRoute, 999) : null;

  const rawGear = Array.isArray(obj.gearItems) ? (obj.gearItems as GearItem[]) : undefined;

  let profile: SkyTrailBackupFile['profile'] = null;
  if (obj.profile && typeof obj.profile === 'object') {
    const p = obj.profile as Record<string, unknown>;
    if (typeof p.name === 'string' && typeof p.email === 'string') {
      profile = {
        name: p.name,
        email: p.email,
        avatarColor: typeof p.avatarColor === 'string' ? p.avatarColor : '#0284c7',
      };
    }
  }

  return {
    schemaVersion: typeof obj.schemaVersion === 'number' ? obj.schemaVersion : 1,
    app: 'SkyTrail',
    exportedAt: typeof obj.exportedAt === 'string' ? obj.exportedAt : new Date().toISOString(),
    profile,
    settings: sanitizedSettings,
    savedRoutes: sanitizedRoutes,
    activeRoute: sanitizedActiveRoute,
    gearItems: rawGear,
  };
}

export function mergeRoutes(existing: RouteData[], incoming: RouteData[]): RouteData[] {
  const byKey = new Map<string, RouteData>();
  for (const r of existing) {
    const key = r.id || r.name.toLowerCase();
    byKey.set(key, r);
  }
  for (const r of incoming) {
    const key = r.id || r.name.toLowerCase();
    if (!byKey.has(key)) {
      byKey.set(key, r);
    }
  }
  return Array.from(byKey.values());
}

export function saveAutoRecoverySnapshot(payload: SkyTrailBackupFile) {
  try {
    localStorage.setItem(AUTO_RECOVERY_KEY, JSON.stringify(payload));
  } catch {
    // Ignore quota errors on large snapshots
  }
}

export function loadAutoRecoverySnapshot(): SkyTrailBackupFile | null {
  try {
    const raw = localStorage.getItem(AUTO_RECOVERY_KEY);
    if (!raw) return null;
    return parseAndValidateBackup(raw);
  } catch {
    return null;
  }
}

export function clearAutoRecoverySnapshot() {
  try {
    localStorage.removeItem(AUTO_RECOVERY_KEY);
  } catch {
    // Ignore
  }
}

export function applyBackupRecovery(params: {
  backup: SkyTrailBackupFile;
  mode: RecoveryMode;
  currentUserId: string | null;
  currentSettings: TripSettings;
  currentRoutes: RouteData[];
  currentActiveRoute: RouteData | null;
}): {
  nextSettings: TripSettings;
  nextRoutes: RouteData[];
  nextActiveRoute: RouteData | null;
} {
  // Always save an undo snapshot before overwriting/merging
  const snapshot = buildBackupPayload({
    user: getActiveUser(),
    settings: params.currentSettings,
    savedRoutes: params.currentRoutes,
    activeRoute: params.currentActiveRoute,
  });
  saveAutoRecoverySnapshot(snapshot);

  const nextSettings = params.backup.settings;
  const nextRoutes =
    params.mode === 'replace'
      ? params.backup.savedRoutes
      : mergeRoutes(params.currentRoutes, params.backup.savedRoutes);

  const nextActiveRoute =
    params.mode === 'replace'
      ? params.backup.activeRoute ?? nextRoutes[0] ?? null
      : params.currentActiveRoute ?? params.backup.activeRoute ?? nextRoutes[0] ?? null;

  saveUserSettings(params.currentUserId, nextSettings);
  saveSavedRoutes(params.currentUserId, nextRoutes);
  if (params.backup.gearItems && params.mode === 'replace') {
    saveGearState(params.currentUserId, params.backup.gearItems);
  }

  return { nextSettings, nextRoutes, nextActiveRoute };
}
