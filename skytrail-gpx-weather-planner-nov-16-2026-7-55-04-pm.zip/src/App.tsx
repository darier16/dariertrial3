/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import {
  AppTab,
  DepartureWindowSummary,
  RouteData,
  SunTimes,
  TripSettings,
  WaypointWeather,
} from './types';
import { Header } from './components/Header';
import { TripControls } from './components/TripControls';
import { WeatherMap } from './components/WeatherMap';
import { TripSummaryCard } from './components/TripSummaryCard';
import { ScheduleTab } from './components/ScheduleTab';
import { GearTab } from './components/GearTab';
import { RoutesTab } from './components/RoutesTab';
import { AnalysisTab } from './components/AnalysisTab';
import { OptionsModal } from './components/OptionsModal';
import { OfflineIndicator } from './components/PWAInstallButton';
import { fetchRouteWeather } from './utils/weatherApi';
import { applyThemeVariables } from './utils/themes';
import { makeRoundTripRouteData, reverseRouteData } from './utils/gpxParser';

const APPEARANCE_STORAGE_KEY = 'skytrail_appearance_v1';

export default function App() {
  const [route, setRoute] = useState<RouteData | null>(() => {
    try {
      const stored = localStorage.getItem('skytrail_saved_routes');
      if (stored) {
        const list: RouteData[] = JSON.parse(stored);
        if (Array.isArray(list) && list.length > 0) return list[0];
      }
    } catch {
      // Ignore storage read errors
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState<AppTab>(() => {
    try {
      const stored = localStorage.getItem('skytrail_saved_routes');
      if (stored) {
        const list = JSON.parse(stored);
        if (Array.isArray(list) && list.length > 0) return 'map';
      }
    } catch {
      // Ignore storage read errors
    }
    return 'routes';
  });

  const [settings, setSettings] = useState<TripSettings>(() => {
    let savedColor: TripSettings['colorTheme'] = 'sky';
    let savedBg: TripSettings['bgMode'] = 'light';
    let savedProvider: TripSettings['weatherProvider'] = 'open_meteo_auto';
    let savedBikeType: TripSettings['bikeType'] = 'gravel';
    let savedSpeed = 22;
    let savedRealistic = true;
    try {
      const raw = localStorage.getItem(APPEARANCE_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.colorTheme) savedColor = parsed.colorTheme;
        if (parsed.bgMode) savedBg = parsed.bgMode;
        if (parsed.weatherProvider) savedProvider = parsed.weatherProvider;
        if (parsed.bikeType) savedBikeType = parsed.bikeType;
        if (typeof parsed.speedKmH === 'number') savedSpeed = parsed.speedKmH;
        if (typeof parsed.realisticPace === 'boolean') savedRealistic = parsed.realisticPace;
      }
    } catch {
      // Ignore storage read errors
    }
    return {
      departureDate: new Date().toISOString().split('T')[0],
      departureTime: '09:00',
      bikeType: savedBikeType,
      speedKmH: savedSpeed,
      breakMinutes: 0,
      realisticPace: savedRealistic,
      colorTheme: savedColor,
      bgMode: savedBg,
      weatherProvider: savedProvider,
    };
  });

  const [isOptionsOpen, setIsOptionsOpen] = useState<boolean>(false);
  const [isDrawingMode, setIsDrawingMode] = useState<boolean>(false);
  const [riderDistanceKm, setRiderDistanceKm] = useState<number | null>(null);

  const [weatherWaypoints, setWeatherWaypoints] = useState<WaypointWeather[]>([]);
  const [sunTimes, setSunTimes] = useState<SunTimes | null>(null);
  const [departureWindows, setDepartureWindows] = useState<DepartureWindowSummary[]>([]);
  const [realisticDurationMinutes, setRealisticDurationMinutes] = useState<number | null>(null);
  const [flatDurationMinutes, setFlatDurationMinutes] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSavedFeedback, setIsSavedFeedback] = useState<boolean>(false);

  // Apply color theme, background mode, and persist preferences immediately
  useEffect(() => {
    applyThemeVariables(settings.colorTheme, settings.bgMode);
    try {
      localStorage.setItem(
        APPEARANCE_STORAGE_KEY,
        JSON.stringify({
          colorTheme: settings.colorTheme,
          bgMode: settings.bgMode,
          weatherProvider: settings.weatherProvider,
          bikeType: settings.bikeType,
          speedKmH: settings.speedKmH,
          realisticPace: settings.realisticPace,
        })
      );
    } catch {
      // Ignore storage write errors
    }
  }, [
    settings.colorTheme,
    settings.bgMode,
    settings.weatherProvider,
    settings.bikeType,
    settings.speedKmH,
    settings.realisticPace,
  ]);

  const loadWeather = useCallback(
    async (targetRoute: RouteData, currentSettings: TripSettings) => {
      setIsLoading(true);
      try {
        const result = await fetchRouteWeather(targetRoute.points, currentSettings);
        setWeatherWaypoints(result.waypoints);
        setSunTimes(result.sunTimes);
        setDepartureWindows(result.departureWindows);
        setRealisticDurationMinutes(result.realisticDurationMinutes);
        setFlatDurationMinutes(result.flatDurationMinutes);
      } catch (err) {
        console.error('Failed to load weather:', err);
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  // Automatically refresh weather when route, date, time, bike speed, break, or provider changes
  useEffect(() => {
    if (!route) return;
    const timer = setTimeout(() => {
      loadWeather(route, settings);
    }, 250);
    return () => clearTimeout(timer);
  }, [
    route,
    settings.departureDate,
    settings.departureTime,
    settings.bikeType,
    settings.speedKmH,
    settings.breakMinutes,
    settings.realisticPace,
    settings.weatherProvider,
    loadWeather,
  ]);

  const handleCalculate = () => {
    if (route) {
      loadWeather(route, settings);
    }
  };

  const handleReverseRoute = () => {
    if (!route) return;
    setRiderDistanceKm(null);
    setRoute(reverseRouteData(route));
  };

  const handleMakeRoundTrip = () => {
    if (!route) return;
    setRiderDistanceKm(null);
    setRoute(makeRoundTripRouteData(route));
  };

  const handleQuickSave = () => {
    if (!route) return;
    try {
      const stored = localStorage.getItem('skytrail_saved_routes');
      const existing: RouteData[] = stored ? JSON.parse(stored) : [];
      const routeToSave: RouteData = {
        ...route,
        id: Date.now().toString(),
        createdAt: new Date().toLocaleDateString('pl-PL'),
      };
      const updated = [routeToSave, ...existing.filter((r) => r.name !== routeToSave.name)];
      localStorage.setItem('skytrail_saved_routes', JSON.stringify(updated));
      setIsSavedFeedback(true);
      setTimeout(() => setIsSavedFeedback(false), 2500);
    } catch {
      // Ignore storage errors
    }
  };

  const handleSelectRoute = (newRoute: RouteData) => {
    setRiderDistanceKm(null);
    setIsDrawingMode(false);
    setRoute(newRoute);
    setActiveTab('map');
  };

  const handleJumpToMapDistance = (km: number) => {
    setRiderDistanceKm(km);
    setActiveTab('map');
  };

  const renderContent = () => {
    if (activeTab === 'routes') {
      return (
        <RoutesTab
          currentRoute={route}
          onSelectRoute={handleSelectRoute}
          onStartDrawingRoute={() => {
            setActiveTab('map');
            setIsDrawingMode(true);
          }}
        />
      );
    }

    if (activeTab === 'gear') {
      return (
        <GearTab
          waypoints={weatherWaypoints}
          route={route}
          settings={settings}
          realisticDurationMinutes={realisticDurationMinutes}
        />
      );
    }

    if (activeTab === 'analysis') {
      if (!route) {
        return (
          <RoutesTab
            currentRoute={null}
            onSelectRoute={handleSelectRoute}
            onStartDrawingRoute={() => {
              setActiveTab('map');
              setIsDrawingMode(true);
            }}
          />
        );
      }
      return (
        <AnalysisTab
          route={route}
          settings={settings}
          waypoints={weatherWaypoints}
          sunTimes={sunTimes}
          realisticDurationMinutes={realisticDurationMinutes}
          onSelectDepartureDate={(date) =>
            setSettings((prev) => ({ ...prev, departureDate: date }))
          }
          onJumpToMapDistance={handleJumpToMapDistance}
        />
      );
    }

    if (activeTab === 'schedule') {
      if (!route) {
        return (
          <RoutesTab
            currentRoute={null}
            onSelectRoute={handleSelectRoute}
            onStartDrawingRoute={() => {
              setActiveTab('map');
              setIsDrawingMode(true);
            }}
          />
        );
      }
      return (
        <ScheduleTab
          route={route}
          settings={settings}
          waypoints={weatherWaypoints}
          colorTheme={settings.colorTheme}
          onJumpToMapDistance={handleJumpToMapDistance}
        />
      );
    }

    if (!route && !isDrawingMode) {
      return (
        <RoutesTab
          currentRoute={null}
          onSelectRoute={handleSelectRoute}
          onStartDrawingRoute={() => {
            setActiveTab('map');
            setIsDrawingMode(true);
          }}
        />
      );
    }

    return (
      <div>
        {route && (
          <TripControls
            route={route}
            settings={settings}
            sunTimes={sunTimes}
            realisticDurationMinutes={realisticDurationMinutes}
            flatDurationMinutes={flatDurationMinutes}
            isDrawingMode={isDrawingMode}
            onToggleDrawingMode={() => setIsDrawingMode((v) => !v)}
            onUpdateSettings={setSettings}
            onCalculate={handleCalculate}
            onReverseRoute={handleReverseRoute}
            onMakeRoundTrip={handleMakeRoundTrip}
            onQuickSave={handleQuickSave}
            onOpenOptions={() => setIsOptionsOpen(true)}
            isSavedFeedback={isSavedFeedback}
            isLoading={isLoading}
          />
        )}

        <WeatherMap
          route={route}
          weatherWaypoints={weatherWaypoints}
          colorTheme={settings.colorTheme}
          isDrawingMode={isDrawingMode}
          onCancelDrawing={() => setIsDrawingMode(false)}
          onCustomRouteCreated={handleSelectRoute}
          riderDistanceKm={riderDistanceKm}
          onRiderDistanceChange={setRiderDistanceKm}
        />

        {route && (
          <TripSummaryCard
            route={route}
            settings={settings}
            waypoints={weatherWaypoints}
            sunTimes={sunTimes}
            realisticDurationMinutes={realisticDurationMinutes}
            departureWindows={departureWindows}
            onSelectDepartureTime={(time) =>
              setSettings((prev) => ({ ...prev, departureTime: time }))
            }
            onReverseRoute={handleReverseRoute}
            onSelectWeatherProvider={(weatherProvider) =>
              setSettings((prev) => ({ ...prev, weatherProvider }))
            }
          />
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen surface-canvas text-slate-900 dark:text-slate-100 font-sans transition-colors">
      <Header
        routeName={route?.name}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenOptions={() => setIsOptionsOpen(true)}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {renderContent()}
      </main>

      <OptionsModal
        isOpen={isOptionsOpen}
        onClose={() => setIsOptionsOpen(false)}
        settings={settings}
        onUpdateSettings={setSettings}
      />

      <OfflineIndicator />
    </div>
  );
}
