import React, { useState, useRef } from 'react';
import {
  RecoveryMode,
  SkyTrailBackupFile,
  UserProfile,
} from '../types';
import {
  authenticateProfile,
  createUserProfile,
  deleteUserProfile,
  loadProfiles,
  loadSavedRoutes,
  parseAndValidateBackup,
} from '../utils/storageAndBackup';
import {
  X,
  User,
  LogIn,
  UserPlus,
  LogOut,
  Download,
  Upload,
  ShieldCheck,
  KeyRound,
  RotateCcw,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  FileJson,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  savedRoutesCount: number;
  hasAutoRecoverySnapshot: boolean;
  onLoginSuccess: (user: UserProfile) => void;
  onLogout: () => void;
  onExportBackup: () => void;
  onApplyBackup: (backup: SkyTrailBackupFile, mode: RecoveryMode, createOrSwitchProfile?: boolean) => void;
  onUndoRecovery: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  savedRoutesCount,
  hasAutoRecoverySnapshot,
  onLoginSuccess,
  onLogout,
  onExportBackup,
  onApplyBackup,
  onUndoRecovery,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [migrateGuest, setMigrateGuest] = useState(true);
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [pendingBackup, setPendingBackup] = useState<SkyTrailBackupFile | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const profiles = loadProfiles();
  const selectedProfile = profiles.find((p) => p.id === selectedProfileId) || null;

  const resetForms = () => {
    setError(null);
    setFeedback(null);
    setPin('');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const user = await createUserProfile({
        name,
        email,
        pin,
        migrateGuestData: migrateGuest,
      });
      setName('');
      setEmail('');
      setPin('');
      onLoginSuccess(user);
      setFeedback('Konto zostało utworzone i aktywowane.');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Nie udało się utworzyć konta.');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const target = selectedProfile ? selectedProfile.id : email;
      if (!target.trim()) {
        setError('Wybierz profil z listy lub wpisz swój adres e-mail.');
        return;
      }
      const user = await authenticateProfile({ emailOrId: target, pin });
      setPin('');
      setSelectedProfileId(null);
      onLoginSuccess(user);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Błąd logowania.');
    }
  };

  const handleQuickProfileClick = async (profile: UserProfile) => {
    setError(null);
    if (!profile.pinHash) {
      try {
        const loggedIn = await authenticateProfile({ emailOrId: profile.id });
        onLoginSuccess(loggedIn);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Błąd logowania.');
      }
    } else {
      setSelectedProfileId(profile.id);
      setEmail(profile.email);
      setPin('');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setFeedback(null);
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        const parsed = parseAndValidateBackup(text);
        setPendingBackup(parsed);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Nie udało się odczytać pliku kopii.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmBackup = (recoveryMode: RecoveryMode) => {
    if (!pendingBackup) return;
    onApplyBackup(pendingBackup, recoveryMode, !currentUser && Boolean(pendingBackup.profile));
    setPendingBackup(null);
    setFeedback(
      recoveryMode === 'replace'
        ? 'Pełne odzyskiwanie zakończone sukcesem. Wszystkie ustawienia i trasy zostały przywrócone.'
        : 'Kopia została scalona z obecnymi danymi.'
    );
  };

  const getInitials = (fullName: string) =>
    fullName
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() || '')
      .join('') || 'U';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 backdrop-blur-xs p-4"
      onClick={onClose}
    >
      <div
        className="surface-card border border-theme rounded-3xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-2 rounded-xl surface-subtle transition-colors cursor-pointer"
          aria-label="Zamknij okno konta"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hidden JSON backup file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".json,application/json"
          onChange={handleFileChange}
          className="hidden"
        />

        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 rounded-2xl accent-gradient text-white flex items-center justify-center shadow-sm shrink-0">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {currentUser ? 'Twoje konto i kopia zapasowa' : 'Logowanie i odzyskiwanie'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Przełączaj profile lokalne, zapisuj ustawienia do pliku i odzyskuj trasy
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-xs font-semibold text-rose-700 dark:text-rose-300 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {feedback && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 text-xs font-semibold text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Pending Backup Preview Step */}
        {pendingBackup ? (
          <div className="surface-subtle border border-theme rounded-2xl p-4 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent-soft text-accent flex items-center justify-center shrink-0">
                <FileJson className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Podgląd kopii zapasowej do odzyskania
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Utworzono:{' '}
                  {new Date(pendingBackup.exportedAt).toLocaleString('pl-PL')}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="surface-card border border-theme rounded-xl p-2.5">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                  Zapisane trasy
                </span>
                <span className="font-bold text-slate-900 dark:text-white font-mono">
                  {pendingBackup.savedRoutes.length} tras
                </span>
              </div>
              <div className="surface-card border border-theme rounded-xl p-2.5">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                  Profil w pliku
                </span>
                <span className="font-bold text-slate-900 dark:text-white truncate block">
                  {pendingBackup.profile?.name || 'Tryb lokalny'}
                </span>
              </div>
              <div className="surface-card border border-theme rounded-xl p-2.5 col-span-2">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                  Ustawienia w kopii
                </span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  Rower: {pendingBackup.settings.bikeType.toUpperCase()} ({pendingBackup.settings.speedKmH} km/h), model: {pendingBackup.settings.weatherProvider}, motyw: {pendingBackup.settings.colorTheme}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => handleConfirmBackup('merge')}
                className="flex-1 px-4 py-2.5 bg-accent text-white font-semibold rounded-xl text-xs hover:opacity-95 transition-opacity cursor-pointer"
              >
                Scal z obecnymi trasami
              </button>
              <button
                type="button"
                onClick={() => handleConfirmBackup('replace')}
                className="flex-1 px-4 py-2.5 surface-card border border-theme text-slate-800 dark:text-slate-100 font-semibold rounded-xl text-xs hover:border-[var(--accent)] transition-colors cursor-pointer"
              >
                Zastąp wszystko z pliku
              </button>
            </div>
            <button
              type="button"
              onClick={() => setPendingBackup(null)}
              className="w-full py-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white cursor-pointer"
            >
              Anuluj przywracanie
            </button>
          </div>
        ) : currentUser ? (
          /* Logged-in User Dashboard */
          <div className="space-y-5">
            <div className="surface-subtle border border-theme rounded-2xl p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-12 h-12 rounded-2xl text-white font-bold text-base flex items-center justify-center shrink-0 shadow-xs"
                  style={{ backgroundColor: currentUser.avatarColor }}
                >
                  {getInitials(currentUser.name)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {currentUser.name}
                    </span>
                    <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {currentUser.email}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 font-mono">
                    Zapisanych tras na koncie: {savedRoutesCount}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onLogout();
                  setFeedback(null);
                  setError(null);
                }}
                className="px-3 py-2 surface-card border border-theme rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-rose-400 hover:text-rose-600 dark:hover:text-rose-400 flex items-center gap-1.5 shrink-0 cursor-pointer transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Wyloguj</span>
              </button>
            </div>

            {/* Backup & Recovery Actions */}
            <div className="space-y-2.5">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Kopia zapasowa i odzyskiwanie danych
              </div>
              <button
                type="button"
                onClick={() => {
                  onExportBackup();
                  setFeedback('Zapisano pełną kopię ustawień i tras do pliku .json.');
                }}
                className="w-full px-4 py-3 bg-accent text-white font-semibold rounded-2xl text-xs shadow-xs hover:opacity-95 transition-opacity flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Zapisz wszystkie ustawienia i trasy do pliku (.json)</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full px-4 py-3 surface-subtle border border-theme text-slate-800 dark:text-slate-100 font-semibold rounded-2xl text-xs hover:border-[var(--accent)] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4 text-accent" />
                <span>Odzyskaj ustawienia i trasy z pliku (.json)</span>
              </button>

              {hasAutoRecoverySnapshot && (
                <button
                  type="button"
                  onClick={() => {
                    onUndoRecovery();
                    setFeedback('Przywrócono stan sprzed ostatniej operacji odzyskiwania.');
                  }}
                  className="w-full px-4 py-2.5 surface-card border border-amber-300 dark:border-amber-700/60 text-amber-800 dark:text-amber-300 font-semibold rounded-2xl text-xs hover:opacity-90 transition-opacity flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Cofnij ostatnie przywracanie (odzyskaj poprzedni stan)</span>
                </button>
              )}
            </div>

            {/* Account deletion with confirmation */}
            <div className="pt-3 border-t border-theme flex items-center justify-between gap-3">
              {confirmDeleteId === currentUser.id ? (
                <div className="flex items-center justify-between gap-2 w-full">
                  <span className="text-[11px] font-semibold text-rose-600 dark:text-rose-400">
                    Usunąć profil lokalny z tej przeglądarki?
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        deleteUserProfile(currentUser.id);
                        setConfirmDeleteId(null);
                        onLogout();
                      }}
                      className="px-3 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      Potwierdź
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(null)}
                      className="px-3 py-1.5 surface-subtle rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      Anuluj
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteId(currentUser.id)}
                  className="text-[11px] font-semibold text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Usuń to konto z urządzenia</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          /* Logged-out Login / Register View */
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-1 surface-subtle p-1 rounded-xl border border-theme">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  resetForms();
                }}
                className={`py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  mode === 'login'
                    ? 'bg-accent text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Zaloguj się</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  resetForms();
                }}
                className={`py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  mode === 'register'
                    ? 'bg-accent text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Nowe konto</span>
              </button>
            </div>

            {mode === 'login' ? (
              <div className="space-y-4">
                {profiles.length > 0 && (
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-2">
                      Zapisane profile na tym urządzeniu:
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                      {profiles.map((p) => {
                        const routeCount = loadSavedRoutes(p.id).length;
                        const isPicked = selectedProfileId === p.id;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => handleQuickProfileClick(p)}
                            className={`w-full flex items-center justify-between gap-3 p-2.5 rounded-2xl border text-left transition-all cursor-pointer ${
                              isPicked
                                ? 'border-[var(--accent)] ring-2 ring-[var(--accent)]/25 surface-subtle'
                                : 'border-theme surface-subtle hover:border-[var(--accent)]/60'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-9 h-9 rounded-xl text-white text-xs font-bold flex items-center justify-center shrink-0"
                                style={{ backgroundColor: p.avatarColor }}
                              >
                                {getInitials(p.name)}
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                  {p.name}
                                </div>
                                <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                                  {p.email} • {routeCount} tras
                                </div>
                              </div>
                            </div>
                            <span className="text-[11px] font-semibold text-accent shrink-0 flex items-center gap-1">
                              {p.pinHash && <KeyRound className="w-3 h-3" />}
                              <span>Wybierz</span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Adres e-mail
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        setSelectedProfileId(null);
                      }}
                      placeholder="twoj@email.pl"
                      className="w-full px-3.5 py-2.5 surface-subtle border border-theme rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Hasło / PIN (jeśli ustawiono)
                    </label>
                    <input
                      type="password"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="••••"
                      className="w-full px-3.5 py-2.5 surface-subtle border border-theme rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-accent text-white font-semibold rounded-xl text-xs shadow-xs hover:opacity-95 transition-opacity cursor-pointer"
                  >
                    {selectedProfile
                      ? `Zaloguj jako ${selectedProfile.name}`
                      : 'Zaloguj się'}
                  </button>
                </form>
              </div>
            ) : (
              <form onSubmit={handleRegister} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Nazwa / Imię rowerzysty
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="np. Marek Kolarz"
                    className="w-full px-3.5 py-2.5 surface-subtle border border-theme rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Adres e-mail
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="marek@rower.pl"
                    className="w-full px-3.5 py-2.5 surface-subtle border border-theme rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Hasło lub PIN (opcjonalnie)
                  </label>
                  <input
                    type="password"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="Pozostaw puste dla szybkiego logowania"
                    className="w-full px-3.5 py-2.5 surface-subtle border border-theme rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                  />
                </div>
                <label className="flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={migrateGuest}
                    onChange={(e) => setMigrateGuest(e.target.checked)}
                    className="rounded border-theme text-accent focus:ring-[var(--accent)]"
                  />
                  <span>Przenieś obecne ustawienia i trasy do nowego konta</span>
                </label>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-accent text-white font-semibold rounded-xl text-xs shadow-xs hover:opacity-95 transition-opacity cursor-pointer"
                >
                  Utwórz konto i zaloguj
                </button>
              </form>
            )}

            {/* File Backup / Recovery available even before logging in */}
            <div className="pt-4 border-t border-theme space-y-2">
              <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                Masz zapisany plik kopii z innego urządzenia?
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onExportBackup();
                    setFeedback('Wyeksportowano bieżące ustawienia i trasy do pliku .json.');
                  }}
                  className="px-3 py-2.5 surface-subtle border border-theme rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-[var(--accent)] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-accent" />
                  <span>Zapisz kopię (.json)</span>
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-2.5 surface-subtle border border-theme rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-[var(--accent)] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-accent" />
                  <span>Odzyskaj z pliku</span>
                </button>
              </div>
              {hasAutoRecoverySnapshot && (
                <button
                  type="button"
                  onClick={() => {
                    onUndoRecovery();
                    setFeedback('Przywrócono poprzedni stan z auto-kopii.');
                  }}
                  className="w-full px-3 py-2 surface-card border border-amber-300 dark:border-amber-700/60 text-amber-800 dark:text-amber-300 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Cofnij ostatnie przywracanie</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
