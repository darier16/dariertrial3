import React from 'react';
import { BgMode, ColorTheme, TripSettings, WeatherProvider } from '../types';
import { BG_MODES, COLOR_THEMES } from '../utils/themes';
import { WEATHER_PROVIDERS } from '../utils/weatherApi';
import { Settings, X, Palette, Layers, Check, CloudSun } from 'lucide-react';

interface OptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TripSettings;
  onUpdateSettings: (settings: TripSettings) => void;
}

export const OptionsModal: React.FC<OptionsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const themeList = Object.values(COLOR_THEMES);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 backdrop-blur-xs p-4"
      onClick={onClose}
    >
      <div
        className="surface-card border border-theme rounded-3xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white p-2 rounded-xl surface-subtle transition-colors cursor-pointer"
          aria-label="Zamknij ustawienia"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-2xl accent-gradient text-white flex items-center justify-center shadow-sm shrink-0">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Ustawienia</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Źródło prognozy pogody oraz wygląd aplikacji
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Weather Provider Selector */}
          <div>
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
              <CloudSun className="w-3.5 h-3.5 text-accent" />
              <span>Dostawca pogody (model prognozy)</span>
            </div>
            <div className="space-y-2">
              {WEATHER_PROVIDERS.map((provider) => {
                const isSelected = settings.weatherProvider === provider.id;
                return (
                  <button
                    key={provider.id}
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        weatherProvider: provider.id as WeatherProvider,
                      })
                    }
                    className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[var(--accent)] ring-2 ring-[var(--accent)]/25 surface-subtle'
                        : 'border-theme hover:opacity-90'
                    }`}
                  >
                    <div
                      className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'border-[var(--accent)] bg-accent text-white'
                          : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          {provider.name}
                        </span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-accent-soft text-accent">
                          {provider.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug mt-1">
                        {provider.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Background Mode Selector */}
          <div className="pt-2 border-t border-theme">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-accent" />
              <span>Kolor tła i tryb ekranu</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {BG_MODES.map((mode) => {
                const isSelected = settings.bgMode === mode.id;
                const previewBg =
                  mode.id === 'tinted'
                    ? COLOR_THEMES[settings.colorTheme].tintCanvas
                    : mode.previewBg;
                return (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, bgMode: mode.id as BgMode })}
                    className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[var(--accent)] ring-2 ring-[var(--accent)]/25 surface-subtle'
                        : 'border-theme hover:opacity-90'
                    }`}
                  >
                    <div
                      className="w-10 h-10 rounded-xl border border-slate-300/60 dark:border-slate-700 shrink-0 flex items-end justify-end p-1 shadow-xs"
                      style={{ backgroundColor: previewBg }}
                    >
                      <div
                        className="w-5 h-5 rounded-md border border-slate-300/50"
                        style={{ backgroundColor: mode.previewCard }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center justify-between gap-1">
                        <span className="truncate">{mode.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-accent shrink-0" />}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug mt-0.5">
                        {mode.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 8 Accent Color Themes */}
          <div>
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-accent" />
              <span>Schemat kolorów ({themeList.length} motywów)</span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {themeList.map((theme) => {
                const isSelected = settings.colorTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ ...settings, colorTheme: theme.id as ColorTheme })
                    }
                    className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[var(--accent)] ring-2 ring-[var(--accent)]/25 surface-subtle'
                        : 'border-theme hover:opacity-90'
                    }`}
                  >
                    <span
                      className="w-7 h-7 rounded-xl shrink-0 shadow-xs flex items-center justify-center text-white"
                      style={{
                        background: `linear-gradient(135deg, ${theme.primary}, ${theme.secondary})`,
                      }}
                    >
                      {isSelected && <Check className="w-4 h-4" />}
                    </span>
                    <span className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {theme.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-theme flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 bg-accent text-white font-semibold rounded-xl text-xs shadow-sm transition-opacity hover:opacity-95 cursor-pointer"
          >
            Gotowe
          </button>
        </div>
      </div>
    </div>
  );
};
